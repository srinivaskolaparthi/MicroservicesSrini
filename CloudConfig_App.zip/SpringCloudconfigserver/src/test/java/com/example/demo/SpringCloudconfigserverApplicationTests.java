package com.example.demo;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringCloudconfigserverApplicationTests {

	@Test
public	void contextLoads() {
	}

}
