package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;
@EnableConfigServer //to enable config server
@SpringBootApplication
public class SpringCloudconfigserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudconfigserverApplication.class, args);
	}

}
