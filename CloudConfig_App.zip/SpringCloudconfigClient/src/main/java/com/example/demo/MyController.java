package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

//@RefreshScope
@RestController
public class MyController {

	@Value("${spring.datasource.driver-class-name}")
	private String driverClassName;

	@Value("${spring.datasource.url}")//spel
	private String url;

	@Value("${spring.datasource.username}")
	private String userName;

	@Value("${spring.datasource.password}")
	private String password;

	@RequestMapping("/showConfig")
	@ResponseBody
	public String showConfig() {
		String configInfo = "<br/>spring.datasource.driver-class-name=" + driverClassName //
				+ "<br/>spring.datasource.url=" + url //
				+ "<br/>spring.datasource.username=" + userName //
				+ "<br/>spring.datasource.password=" + password;

		return configInfo;
	}

}